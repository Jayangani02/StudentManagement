import java.util.Scanner; // import scanner package
import java.io.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;

public class UniversityManagementSystem {
    private static final int STUDENT = 100;// Maximum student count.
    private static Student[] students = new Student[STUDENT];
    private static int studentCount = 0;


    public static void main(String[] args) {
        loadStudentDetails(); // load student details
        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            System.out.println("Menu:");
            System.out.println("1. Check available seats");
            System.out.println("2. Register Student");
            System.out.println("3.Delete Student Details");
            System.out.println("4.Find Student");
            System.out.println("5. Store Student details into a file");
            System.out.println("6. Load student details into a file");
            System.out.println("7. View the list of students based on Their names");
            System.out.println("8. Additional controls");
            System.out.println("9. Exit");

            System.out.println("Select an option: ");
            option = scanner.nextInt(); // get input
            scanner.nextLine();

            switch (option) {
                case 1:
                    checkAvailableSeats();
                    break;
                case 2:
                    registerStudent(scanner);
                    break;
                case 3:
                    deleteStudent(scanner);
                    break;
                case 4:
                    findStudent(scanner);
                    break;
                case 5:
                    storeStudentDetails();
                    break;
                case 6:
                    loadStudentDetails();
                    break;
                case 7:
                    viewStudentsDetails();
                    break;
                case 8:
                    additionalControl(scanner);
                    break;
                case 9:
                    System.out.println("Exit");
                    break;
                default:
                    System.out.println("Invalid option.Please try again!");

            }
        } while (option != 9);
    }

    private static void checkAvailableSeats() {
        System.out.println("Available seats: " + (STUDENT - studentCount));

    }

    private static void registerStudent(Scanner scanner) {
        if (studentCount >= STUDENT) {
            System.out.println("No available seats"); // handle the error if User enter the more than 100 no of seats.
            return;
        }
        System.out.println("Enter Student ID: "); // Get student ID from user
        String id = scanner.nextLine();
        System.out.println("Enter student name: "); // Get student name
        String name = scanner.nextLine();

        students[studentCount++] = new Student(id, name);
        System.out.println("Student registered successfully.");
    }


    private static void deleteStudent(Scanner scanner) {
        System.out.println("Enter student ID to delete: ");
        String id = scanner.nextLine();
        boolean found = false;

        for (int i = 0; i < studentCount; i++) { // Delete the Student details according to the user inputs.
            if (students[i].getID().equals(id)) {
                students[i] = students[--studentCount];
                students[studentCount] = null;
                found = true;
                System.out.println("Student deleted successfully.");
                break;
            }
        }
        if (!found) {
            System.out.println("Student not found.");// Handle the delete student details if user enter the Id number without of file.
        }
    }

    private static void findStudent(Scanner scanner) {
        System.out.println("Enter student ID to find: "); // Get Student ID to find from file.
        String id = scanner.nextLine();

        for (int i = 0; i < studentCount; i++) {
            if (students[i].getID().equals(id)) {
                System.out.println(students[i]);
                return;
            }
        }
        System.out.println("Student not found"); // Handle the find student error.
    }

    private static void storeStudentDetails() {
        try (PrintWriter writer = new PrintWriter(new File("students.txt"))) { // t.o write a data into a file
            for (int i = 0; i < studentCount; i++) {
                Student student = students[i];
                Module module = student.getModule();
                writer.println(student.getID() + "," + student.getName() + "," +
                        (module  != null ? student.getModule().getSD1Marks() + "," + student.getModule().getCSFMarks() + "," + student.getModule().getMFCMarks() : "null,null,null"));
            }
            System.out.println("Student details stored successfully.");
        } catch (IOException e) {
            System.out.println(" Writing error!: " + e.getMessage()); //Handle the store details error.
        }
    }
    private static void loadStudentDetails(){
        try (BufferedReader reader = new BufferedReader(new FileReader("Students.txt"))) { // to load a details into .txt file using bufferedreader

            String line;
            studentCount = 0;
            while ((line = reader.readLine()) != null && studentCount < STUDENT) { // to read line by line.
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    Student student = new Student(parts[0], parts[1]);
                    if (parts.length == 5 && !"null".equals(parts[2])) {
                        Module module = new Module(Integer.parseInt(parts[2]), Integer.parseInt(parts[3]), Integer.parseInt(parts[4]));
                        student.setModule(module);
                    }
                    students[studentCount++] = student;

                } else {
                    System.out.println("Invaild line: " + line); // Handle the line error.
                }
            }
            System.out.println("Student details loaded successfully.");

        }catch (IOException e){ //Handle the error.
            System.out.println("File not found.");
        }catch (NumberFormatException e){
            System.out.println("Error parsing number from a file.");
        }
    }


    private static void viewStudentsDetails() { // View all students and their names, module marks

        for (int i = 0; i < studentCount; i++) {
            System.out.println(students[i]);
        }
    }

    
    private static void additionalControl(Scanner scanner) {
    System.out.println("Additional control:");
        System.out.println("a. Add Student name");
        System.out.println("b. Add module marks");
        System.out.println("c. Summary");
        System.out.println("d. Total report");

        System.out.print("Select an option: ");
        char subOption = scanner.nextLine().charAt(0);

        switch (subOption) {
            case 'a':
                addStudent(scanner);
                break;
            case 'b':
                addModMarks(scanner);
                break;
            case 'c':
                summary();
                break;
            case 'd':
                totalReport();
                break;
            default:
                System.out.println("Invalid option. Please try again!");
        }
    }

    private static void addStudent(Scanner scanner) {
        System.out.println("Enter student ID: ");
        String id = scanner.nextLine();

        for (int i = 0; i < studentCount; i++) {
            if (students[i].getID().equals(id)) {
                System.out.println("Enter new student name: ");
                String name = scanner.nextLine();
                students[i].setName(name);
                System.out.println("Student name added successfully!");
                return;
            }
        }
        System.out.println("Student not found!");
    }

    private static void addModMarks(Scanner scanner) { // add module marks into file
        System.out.println("Enter student ID: ");
        String id = scanner.nextLine();

        for (int i = 0; i < studentCount; i++) {
            if (students[i].getID().equals(id)) {
                System.out.println("Enter SD1 Marks: ");
                int SD1Mark = scanner.nextInt();
                System.out.println("Enter CSF Marks: ");
                int CSFMark = scanner.nextInt();
                System.out.println("Enter MFC Marks: ");
                int MFCMark = scanner.nextInt();
                scanner.nextLine();

                Module module = new Module(SD1Mark, CSFMark, MFCMark);
                students[i].setModule(module);
                System.out.println("Module marks added successfully!");
                return;
            }
        }
        System.out.println("student not found.");// Hndle the error.
    }

    private static void summary() {
        int totalStudent = studentCount;
        int SD1Mod = 0;
        int CSFMod = 0;
        int MFCMod = 0;

        for (int i = 0; i < studentCount; i++) {
            Module mod = students[i].getModule();
            if (mod != null) {
                if (mod.getSD1Marks() > 40) {
                    SD1Mod++;
                }

                if (mod.getCSFMarks() > 40) {
                    CSFMod++;
                }
                if (mod.getMFCMarks() > 40) {
                    MFCMod++;
                }
            }
        }
        System.out.println("Summary:");
        System.out.println("Total registered student: " + totalStudent);
        System.out.println(" Total  number of student who passed SD1 Module: " + SD1Mod);
        System.out.println(" Total  number of student who passed CSF Module: " + CSFMod);
        System.out.println(" Total  number of student who passed MFC Module: " + MFCMod);
    }
    private static void totalReport() {
        Student[] sortedStudents = sortStudents(students);
        for (Student student : sortedStudents) {
            if (student != null && student.getModule() != null) {
                Module module = student.getModule();
                System.out.println("Student ID: " + student.getID());
                System.out.println("Student Name: " + student.getName());
                for (int i = 0; i < 3; i++) {
                    System.out.println("Module " + (i + 1) + " marks: " + student.getModule());
                }
                double average =student.getModule().getAverage() ;// get marks and print total and grades.
                System.out.println("Total: " + student.getModule().getSD1Marks() + student.getModule().getCSFMarks() + student.getModule().getMFCMarks());
                System.out.println("Average: " + student.getModule().getAverage());
                System.out.println("Grade: " + student.getModule().getGrade());
                System.out.println();
            }
        }
    }
    private static Student[] sortStudents(Student[] students) {// Sort student by their names.
        Student[] sortedStudents = students.clone();
        for (int i = 0; i < sortedStudents.length - 1; i++) {
            for (int j = 0; j < sortedStudents.length - 1 - i; j++) {
                if (sortedStudents[j] != null && sortedStudents[j + 1] != null) {
                    if (sortedStudents[j].getModule() != null && sortedStudents[j + 1].getModule() != null) {
                        if (sortedStudents[j].getModule().getAverage() < sortedStudents[j + 1].getModule().getAverage()) {
                            Student temp = sortedStudents[j];
                            sortedStudents[j] = sortedStudents[j + 1];
                            sortedStudents[j + 1] = temp;
                        }
                    }
                }
            }
        }

        return sortedStudents;
    }


}



