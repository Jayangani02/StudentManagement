public class Module {

        private int SD1Marks;
        private int CSFMarks;
        private int MFCMarks;

        public Module (int SD1Marks, int CSFMarks, int MFCMarks){
            this.SD1Marks = SD1Marks;
            this.CSFMarks = CSFMarks;
            this.MFCMarks = MFCMarks;

        }
        public int getSD1Marks(){
            return SD1Marks;
        }

        public  int getCSFMarks() {
            return CSFMarks;
        }
        public int getMFCMarks() {
            return MFCMarks;

        }

        public double getAverage() {

            return (SD1Marks + CSFMarks + MFCMarks) / 3.0;
        }
        public  String getGrade(){
            double average = getAverage();
            if (average >= 80){
                return "Distinction";
            } else if (average >= 70) {
                return "Merit";

            } else if (average >= 40) {
                return"Pass";

            }else {
                return "Fail";
            }
        }
        @Override
        public String toString() {
            return "Marks: [" + SD1Marks + "," + CSFMarks + "," + MFCMarks + "], Grade: " + getGrade();
        }

}
