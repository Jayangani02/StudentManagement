public class Student {
    private String id;
    private String name;
    private Module module;


    public Student (String id, String name){
        this.id = id;
        this.name = name;
    }
    public String getID(){
        return id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    public Module getModule(){
        return module;
    }
    public void setModule(Module module){
        this.module = module;
    }

    @Override
    public String toString() {
        return "ID: "+ id +", Name: " + name + ", Module: "  + (module != null ? module : "No module marks");
    }
}

